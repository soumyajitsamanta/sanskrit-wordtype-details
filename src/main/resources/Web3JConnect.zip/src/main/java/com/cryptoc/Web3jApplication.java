package com.cryptoc;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Map;

import org.web3j.crypto.Credentials;
import org.web3j.crypto.MnemonicUtils;
import org.web3j.crypto.WalletUtils;
import org.web3j.protocol.Web3j;
import org.web3j.protocol.core.DefaultBlockParameter;
import org.web3j.protocol.http.HttpService;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Web3jApplication {
    private static final ObjectMapper mapper = new ObjectMapper();

    private static String toJson(Object ob) {
        try {
            return mapper.writerWithDefaultPrettyPrinter()
                    .writeValueAsString(ob);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return "";
    }

    public static void main(String[] args) {
        try {
            Web3j web3j = Web3j
                    .build(new HttpService("http://localhost:8545/"));
            LocalDateTime now = LocalDateTime.now();
            String date = Integer.toString(now.getYear()) + "-"
                    + Integer.toString(now.getMonth().getValue()) + "-"
                    + Integer.toString(now.getDayOfMonth()) + "("
                    + Integer.toString(now.getHour()) + "="
                    + Integer.toString(now.getMinute())+")";
            File log = new File("C:\\Projects\\Documents\\BIP39Was\\log"+date+".txt");
            if (!log.exists()) {
                log.createNewFile();
            }
            FileWriter logWriter = new FileWriter(log, true);
            setupShutdownHook(web3j, logWriter);

            SecureRandom r = new SecureRandom();
            for (int start = 0; start < 1000; start++) {
                byte[] randomBytes = getRandomBytes(r);
                String mnemonic = MnemonicUtils.generateMnemonic(randomBytes);
                String address = getAddressFromMnemonic(mnemonic);
                BigInteger balance = getBalanceForAddress(web3j, address);
                Map<String, String> hashMap = Map.of("mnemonic", mnemonic,
                        "address", address, "balance", balance.toString());
                logWriter.write(toJson(hashMap));
                System.err.println(hashMap);
                logWriter.flush();
                Thread.sleep(1000);
            }
            logWriter.close();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
    }

    private static void setupShutdownHook(Web3j web3j, FileWriter logWriter) {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                logWriter.close();
                web3j.shutdown();
                System.err.println("Shutting Down.");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }));
    }

    private static BigInteger getBalanceForAddress(Web3j web3j, String address)
            throws IOException {
        return web3j
                .ethGetBalance(address,
                        DefaultBlockParameter.valueOf("latest"))
                .send().getBalance();
    }

    private static String getAddressFromMnemonic(String mnemonic) {
        Credentials loadBip39Credentials = WalletUtils
                .loadBip39Credentials("", mnemonic);
        return loadBip39Credentials.getAddress();
    }

    private static byte[] getRandomBytes(SecureRandom r) {
        byte[] bytes = new byte[32];
        r.nextBytes(bytes);
        return bytes;
    }
}
